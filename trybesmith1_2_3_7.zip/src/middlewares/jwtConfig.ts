export const secret = 'Trybe';

export const config: object = {
  expiresIn: '6h',
  algorithm: 'HS256',
};